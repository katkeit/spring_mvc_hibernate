package katkeit.com.github.spring_mvc_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
